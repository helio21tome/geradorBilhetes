<!DOCTYPE html>
    <head>
        <link rel="stylesheet" href="Vsltyle.css" />
    </head>
    <body>
        <?php  
            include 'Vform.php';
        ?>
    </body>
</hrml>