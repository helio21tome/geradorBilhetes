<!DOCTYPE HTML>
    <html lang = "pt-br">

    <head>
        <meta charset = "UTF-8">
        <meta name = "veiwport" content = "widht=device-widht, inicial-scale=1.0">
        <link rel = "stylesheet" href = "css/formstyle.css">;
        <title> Formulario de Cadastro</title>
        <style type="text/css">
            .menu_options{
                margin-top: 30%;
                padding: 15px;
            }

        </style>
    </head>
    <body>

        <div class = "conteiner">

            <div class = "form_image">
                 <div class = "centralizer_img">
                    <img src = "css/imagen/undraw_travel_mode_re_2lxo.svg">
                 </div>
            </div>

            <div class = "header">

                <div class = "title">
                    <h2>Teu espaço de viagens</h2>
                </div>

            </div>         

            <div class="menu_options">
                <bottom><a href="registro.php">Cadastrar |</a></bottom> 
                <bottom><a href="login.php"> Fazer Login</a></bottom>
            </div>

        </div> 

    </body>
</HTML>