<!DOCTYPE html>
    <head> 
     <link rel = "stylesheet" href = "css/pagina_finalizacao"  >
     <style type="text/css">
          .big_conteiner{

               width: 50%;
               margin:auto;
               text-align: center;
          }
     </style>
   </head>
   <body>
     <div class = "big_conteiner">

          <div class = "conteiner">

               <div class = "logo">
                    <h2>FACTURA Y05013023</h2>
               </div>

          </div>

          <div class = "conteiner">

               <diV class = "pagar_a">
                    <strong>Emissao:</strong>
                    <p>Valor a pagar: 900 MT</p>
                    <br><p><select>
                         <option>Metodo de Pagamento</option>
                         <option>M-pesa</option>
                         <option>E-mola</option>
                         <option>Visa card</option>
                    </select></p><br>
               </div>

          </div> 
          <div class = "botao_factura">
               <bottom><a href="c2b.php">Realizar a Compra</a><bottom>
          </div>     
     </div>         
   </body>
</html>